<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StoreDataController extends Controller
{
    public function get_suhu()
    {
        return response()->json(
            1
        );
    }
    public function get_kelembaban()
    {
        return response()->json(
            1
        );
    }
    public function get_ph()
    {
        return response()->json(
            1
        );
    }
    public function get_tinggi_bak_air()
    {
        return response()->json(
            1
        );
    }
    public function get_tinggi_nutrisi_a()
    {
        return response()->json(
            1
        );
    }
    public function get_tinggi_nutrisi_b()
    {
        return response()->json(
            1
        );
    }


    public function store_suhu()
    {
        return response()->json(
            1
        );
    }
    public function store_kelembaban()
    {
        return response()->json(
            1
        );
    }
    public function store_ph()
    {
        return response()->json(
            1
        );
    }
    public function store_tinggi_bak_air()
    {
        return response()->json(
            1
        );
    }
    public function store_tinggi_nutrisi_a()
    {
        return response()->json(
            1
        );
    }
    public function store_tinggi_nutrisi_b()
    {
        return response()->json(
            1
        );
    }
}

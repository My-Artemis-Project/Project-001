<?php

use App\Http\Controllers\StoreDataController;
use Illuminate\Support\Facades\Route;


Route::prefix('store/data/')->controller(StoreDataController::class)->group(function () {
    Route::post('suhu', 'store_suhu');
    Route::post('kelembaban', 'store_kelembaban');
    Route::post('ph', 'store_ph');
    Route::post('tinggi_bak_air', 'store_tinggi_bak_air');
    Route::post('tinggi_nutrisi_a', 'store_tinggi_nutrisi_a');
    Route::post('tinggi_nutrisi_b', 'store_tinggi_nutrisi_b');
});

Route::prefix('get/data/')->controller(StoreDataController::class)->group(function () {
    Route::get('suhu', 'get_suhu');
    Route::get('kelembaban', 'get_kelembaban');
    Route::get('ph', 'get_ph');
    Route::get('tinggi_bak_air', 'get_tinggi_bak_air');
    Route::get('tinggi_nutrisi_a', 'get_tinggi_nutrisi_a');
    Route::get('tinggi_nutrisi_b', 'get_tinggi_nutrisi_b');
});